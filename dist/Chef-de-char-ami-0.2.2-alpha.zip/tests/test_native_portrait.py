from __future__ import absolute_import
import sys, os, unittest
sys.path.insert(0, os.path.dirname(__file__))
from test_core import Tests, Obj, module_at, mod


class NativePortrait(unittest.TestCase):
    def setUp(self):
        Tests.setUp.im_func(self)
        class Tankman(object):
            role = 'commander'
            invID = 10
            def getExtensionLessIconWithSkin(self): return 'original_crew_icon'
            def getFullUserNameWithSkin(self): return 'Original Name'
        self.Tankman = Tankman
        module_at('gui.shared.gui_items.Tankman').Tankman = Tankman
        big = Obj(dyn=lambda name: lambda: 12345, crewSkins=Obj(dyn=lambda name: lambda: 12346))
        module_at('gui.impl.gen').R = Obj(images=Obj(gui=Obj(maps=Obj(icons=Obj(tankmen=Obj(icons=Obj(big=big)))))))
        mod.STATE = {'accounts': {'123': {'10': 'papacito'}}}
        # The current implementation only supplies a DOM overlay, so neither
        # native caller (garage / personal file) receives the selected portrait.
        mod.patch_native_portraits()

    def tearDown(self):
        Tests.tearDown.im_func(self)

    def test_native_portrait_is_selected_and_restored_per_commander(self):
        commander = self.Tankman()
        self.assertEqual(commander.getExtensionLessIconWithSkin(), 'commander_friend_papacito')
        self.assertEqual(commander.getFullUserNameWithSkin(), 'Papacito')
        other = self.Tankman(); other.invID = 11
        self.assertEqual(other.getExtensionLessIconWithSkin(), 'original_crew_icon')
        mod.STATE = {'accounts': {'123': {}}}
        self.assertEqual(commander.getExtensionLessIconWithSkin(), 'original_crew_icon')
        self.assertEqual(commander.getFullUserNameWithSkin(), 'Original Name')

    def test_disabled_portrait_preserves_native_appearance(self):
        mod.SETTINGS['portrait'] = False
        commander = self.Tankman()
        self.assertEqual(commander.getExtensionLessIconWithSkin(), 'original_crew_icon')
        self.assertEqual(commander.getFullUserNameWithSkin(), 'Original Name')

    def test_unknown_native_resource_preserves_original(self):
        big=module_at('gui.impl.gen').R.images.gui.maps.icons.tankmen.icons.big
        big.dyn=lambda name:lambda:-1
        self.assertEqual(self.Tankman().getExtensionLessIconWithSkin(),'original_crew_icon')

    def test_both_normal_and_equipped_appearance_use_the_same_local_icon(self):
        commander=self.Tankman()
        for equipped in (False, True):
            commander.isInSkin=equipped
            self.assertEqual(commander.getExtensionLessIconWithSkin(),'commander_friend_papacito')
            self.assertEqual(commander.isInSkin,equipped)

    def test_open_personal_file_refreshes_on_deactivation(self):
        commander=self.Tankman()
        class Info(object):
            def __init__(self):
                self.context=Obj(tankman=commander)
                self.viewModel=Obj()
            def _setTankmanInfo(self, model):
                model.icon=self.context.tankman.getExtensionLessIconWithSkin()
                model.name=self.context.tankman.getFullUserNameWithSkin()
        module_at('gui.impl.lobby.crew.container_vews.common.tankman_info_component').TankmanInfoComponent=Info
        mod.patch_personal_file()
        component=Info();component._setTankmanInfo(component.viewModel)
        self.assertEqual(component.viewModel.icon,'commander_friend_papacito')
        mod.STATE={'accounts':{'123':{}}}
        mod.PRESENTERS=[];mod.snapshot_current=lambda:None;mod.payload=lambda:'{}'
        self.originals['refresh']()
        self.assertEqual(component.viewModel.icon,'original_crew_icon')
        self.assertEqual(component.viewModel.name,'Original Name')


if __name__ == '__main__':
    unittest.main(defaultTest='NativePortrait')
